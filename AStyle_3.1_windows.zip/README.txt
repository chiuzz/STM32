1、解压到keil安装目录；
2、打开keil--Customize Tools Menu；
3、添加AStyle Current File，command设置路径，Arguments添加指令!E;
4、添加AStyle All File，command设置路径，Arguments添加指令"$E*.c" "$E*.h"